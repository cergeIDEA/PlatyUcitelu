# PlatyUcitelu
Infografika na platy ucitelu
